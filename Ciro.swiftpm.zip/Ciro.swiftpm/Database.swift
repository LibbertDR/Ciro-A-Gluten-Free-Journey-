//
//  Database.swift
//  Ciro
//
//  Created by Alberto Di Ronza on 14/04/23.
//


import Foundation

let wheat: Crops = Crops(cropType: "Wheat", scoreCrop: 0)
let kamut: Crops = Crops(cropType: "Kamut", scoreCrop: 0)
let spelt: Crops = Crops(cropType: "Spelt", scoreCrop: 0)
let barley: Crops = Crops(cropType: "Barley", scoreCrop: 0)
let rice: Crops = Crops(cropType: "Rice", scoreCrop: 100)
let corn: Crops = Crops(cropType: "Corn", scoreCrop: 100)
let quinoa: Crops = Crops(cropType: "Quinoa", scoreCrop: 200)
    
public var possibleCrops : [Crops] = [wheat, kamut, spelt, barley, rice, corn, quinoa]
