import SwiftUI
import SpriteKit

struct ContentView: View {
    var scene: SKScene {
        let gameScene = GameScene()
        gameScene.size = CGSize(width: 300, height: 400)
        gameScene.scaleMode = .resizeFill
        gameScene.scaleMode = .fill
        gameScene.scaleMode = .aspectFill
               return gameScene
        }
//    let skView = SKView(frame: .zero)
   
   
    var body: some View {
//        gameScene.scaleMode = .aspectFill
//        skView.presentScene(gameScene)
        SpriteView(scene: scene)
            .ignoresSafeArea()
    }
}
