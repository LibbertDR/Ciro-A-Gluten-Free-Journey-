//
//  DataStruct.swift
//  Ciro
//
//  Created by Alberto Di Ronza on 14/04/23.
//

import Foundation

public struct Crops {
    let cropType: String
    let scoreCrop: Int
}

