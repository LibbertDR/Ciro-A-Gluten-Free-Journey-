import SpriteKit
import GameplayKit
import CoreMotion

public class GameScene: SKScene, SKPhysicsContactDelegate {
    //-MARK: VAR & LET
    let player = SKSpriteNode(texture: SKTexture(imageNamed: "Ciro"))
    
    let heart = SKSpriteNode(texture: SKTexture(imageNamed: "Heart"))
    var livesLabel: SKLabelNode!
    var lives: Int = 0 {
        didSet {
            livesLabel.text = "x\(lives)"
        }
    }
    
    var scoreLabel: SKLabelNode!
    var score: Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }
    
    var scoreCrop : Int!
    var cropsTimer: Timer!
    
    //IDENTIFIERS
    let cropCategory:UInt32 = 0x1 << 1
    let ciroCategory:UInt32 = 0x1 << 0
    
    let bg = SKSpriteNode(texture: SKTexture(imageNamed: "BackGround"))
    
    public override func didMove (to view: SKView) {
        
        //-MARK: MAIN CHARACTER
        player.position = CGPoint(x: frame.midX, y: frame.midY/2)
        player.size.width  = player.size.width/2
        player.size.height = player.size.height/2
        addChild(player)
        
        //Physics for contact detection
        physicsWorld.gravity = CGVector(dx: 0 , dy: 0)
        physicsWorld.contactDelegate = self
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        player.physicsBody?.isDynamic = true
        
        player.physicsBody?.categoryBitMask = ciroCategory
        player.physicsBody?.contactTestBitMask = cropCategory
        player.physicsBody?.collisionBitMask = 0
        player.physicsBody?.usesPreciseCollisionDetection = true
        
        //-MARK: LIVES
        heart.position = CGPoint (x: frame.midX * 1.6, y: frame.midY * 0.15)
        heart.size.width  = heart.size.width/2
        heart.size.height = heart.size.height/2
        heart.zPosition = 10
        addChild(heart)
        
        livesLabel = SKLabelNode (text: "x3")
        livesLabel.position = CGPoint (x: frame.midX * 1.75, y: frame.midY * 0.1)
        livesLabel.fontName =
            "AmericanTypewriter-Bold"
        livesLabel.fontSize = 14
        livesLabel.fontColor = UIColor.white
        lives = 3
        livesLabel.zPosition = 10
        self.addChild(livesLabel)
        
        //-MARK: SCORE
        scoreLabel = SKLabelNode (text: "Score: 0")
        scoreLabel.position = CGPoint (x: frame.midX, y: frame.midY * 1.8)
        scoreLabel.fontName =
            "AmericanTypewriter-Bold"
        scoreLabel.fontSize = 16
        scoreLabel.fontColor = UIColor.white
        score = 0
        scoreLabel.zPosition = 10
        self.addChild(scoreLabel)
            
        //-MARK: CROPS
        cropsTimer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(addCrops), userInfo: nil, repeats: true)
        
        //-MARK: BACKGROUND
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
    }
    
    //-MARK: CROPS MANAGEMENT
    @objc func addCrops(){
        
        possibleCrops = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: possibleCrops) as! [Crops]
        let crop = SKSpriteNode (imageNamed: possibleCrops[0].cropType)
        let randomCropPosition = GKRandomDistribution(lowestValue: 0, highestValue: Int(frame.size.width))
        let position = CGFloat(randomCropPosition.nextInt())
        
        crop.position = CGPoint(x: position , y: self.frame.size.height + crop.size.height)
        
        //ADDING PHYSICS CHARACTERISTICS TO CROPS
        crop.physicsBody = SKPhysicsBody(rectangleOf: crop.size)
        crop.physicsBody?.isDynamic = true
        
        crop.physicsBody?.categoryBitMask = cropCategory
        crop.physicsBody?.contactTestBitMask = ciroCategory
        crop.physicsBody?.collisionBitMask = 0
        
        scoreCrop = possibleCrops[0].scoreCrop
        
        self.addChild (crop)
        
        //CROPS MOVEMENT
        let animationDuration: TimeInterval = 6
        var actionArray = [SKAction]()
        actionArray.append (SKAction.move(to: CGPoint(x: position, y: -crop.size.height), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        crop.run (SKAction.sequence (actionArray))
    }
    
    //-MARK: BIRD MOVEMENT
    public override func touchesMoved (_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            player.position.x = location.x
        }
    }
    
    //-MARK: CONTACT MANAGING
    public func didBegin(_ contact: SKPhysicsContact) {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
            
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
        firstBody = contact.bodyA
        secondBody = contact.bodyB
        }
            else{
                firstBody = contact.bodyB
                secondBody = contact.bodyA
            }
           
           if (firstBody.categoryBitMask & ciroCategory) != 0 && (secondBody.categoryBitMask & cropCategory) != 0 {
        birdDidCollideWithCrop(birdNode: firstBody.node as! SKSpriteNode, cropNode: secondBody.node as! SKSpriteNode)
        }
        
    func birdDidCollideWithCrop(birdNode : SKSpriteNode , cropNode : SKSpriteNode ) {
        if(scoreCrop == 0){
            lives -= 1
            cropNode.removeFromParent()
        }
        else{
            score += scoreCrop
            cropNode.removeFromParent()
        }
           }
    }
}
